<?php

    define("DATABASE_HOST", "localhost"); // Definition de constant
    define("DATABASE_USER", "root");
    define("DATABASE_PASS", "");
    define("DATABASE_NAME", "boucherie");
    define("DOMAINE", "http://localhost/webforce3/Mike/Php/Project/");
